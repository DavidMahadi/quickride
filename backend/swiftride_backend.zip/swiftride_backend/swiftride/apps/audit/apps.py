from django.apps import AppConfig
class AuditConfig (AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name  = 'swiftride.apps.audit'
    label = 'audit'
