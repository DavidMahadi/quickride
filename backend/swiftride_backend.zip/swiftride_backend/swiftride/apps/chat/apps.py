from django.apps import AppConfig
class ChatConfig (AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name  = 'swiftride.apps.chat'
    label = 'chat'
