from rest_framework import generics, status, permissions
from rest_framework.response import Response
from swiftride.apps.companies.permissions import IsCompanyStaff, IsSuperAdmin
from swiftride.apps.audit.utils import log_action
from .models import Booking, BookingStatusLog
from .serializers import BookingSerializer, CreateBookingSerializer, BookingMiniSerializer


class CreateBookingView(generics.CreateAPIView):
    serializer_class = CreateBookingSerializer

    def perform_create(self, serializer):
        booking = serializer.save()
        log_action(self.request.user, 'create', 'Booking', str(booking.id),
                   f'Booking {booking.ref} created')


class MyBookingsView(generics.ListAPIView):
    serializer_class = BookingMiniSerializer

    def get_queryset(self):
        qs = Booking.objects.filter(customer=self.request.user).select_related('car', 'company')
        status_filter = self.request.query_params.get('status')
        if status_filter:
            qs = qs.filter(status=status_filter)
        return qs


class BookingDetailView(generics.RetrieveAPIView):
    serializer_class = BookingSerializer

    def get_queryset(self):
        user = self.request.user
        if user.is_super_admin:
            return Booking.objects.all()
        if user.role in ('company_admin', 'company_staff'):
            return Booking.objects.filter(company=user.company)
        return Booking.objects.filter(customer=user)


class CancelBookingView(generics.GenericAPIView):
    def post(self, request, pk):
        booking = Booking.objects.get(pk=pk, customer=request.user)
        if booking.status not in ('pending', 'confirmed'):
            return Response({'detail': 'Cannot cancel this booking.'}, status=400)
        reason = request.data.get('reason', '')
        booking.cancel(reason)
        # Free the car
        booking.car.status = 'available'
        booking.car.save(update_fields=['status'])
        BookingStatusLog.objects.create(
            booking=booking, from_status='confirmed',
            to_status='cancelled', changed_by=request.user, note=reason
        )
        log_action(request.user, 'update', 'Booking', str(booking.id), f'{booking.ref} cancelled')
        return Response({'detail': 'Booking cancelled.'})


class CompanyBookingListView(generics.ListAPIView):
    serializer_class   = BookingSerializer
    permission_classes = [IsCompanyStaff]

    def get_queryset(self):
        qs = Booking.objects.filter(company=self.request.user.company).select_related('customer','car')
        status_filter = self.request.query_params.get('status')
        if status_filter:
            qs = qs.filter(status=status_filter)
        return qs


class UpdateBookingStatusView(generics.GenericAPIView):
    permission_classes = [IsCompanyStaff]

    def post(self, request, pk):
        booking    = Booking.objects.get(pk=pk, company=request.user.company)
        new_status = request.data.get('status')
        allowed    = ('confirmed', 'active', 'completed', 'cancelled')
        if new_status not in allowed:
            return Response({'detail': f'Status must be one of {allowed}'}, status=400)

        old_status = booking.status
        booking.status = new_status
        booking.save(update_fields=['status', 'updated_at'])

        if new_status == 'completed':
            booking.car.status = 'available'
            booking.car.total_trips += 1
            booking.car.save(update_fields=['status', 'total_trips'])

        BookingStatusLog.objects.create(
            booking=booking, from_status=old_status, to_status=new_status,
            changed_by=request.user, note=request.data.get('note', '')
        )
        log_action(request.user, 'update', 'Booking', str(booking.id),
                   f'{booking.ref} status changed {old_status} → {new_status}')
        return Response({'detail': f'Status updated to {new_status}.'})


class AdminBookingListView(generics.ListAPIView):
    serializer_class   = BookingSerializer
    permission_classes = [IsSuperAdmin]
    queryset           = Booking.objects.all().select_related('customer', 'car', 'company')
    filterset_fields   = ['status', 'payment_status', 'company']
    search_fields      = ['ref', 'customer__full_name', 'car__name']
