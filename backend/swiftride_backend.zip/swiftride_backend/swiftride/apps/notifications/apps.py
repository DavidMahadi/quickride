from django.apps import AppConfig
class NotificationsConfig (AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name  = 'swiftride.apps.notifications'
    label = 'notifications'
