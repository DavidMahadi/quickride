from django.apps import AppConfig
class WalletConfig (AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name  = 'swiftride.apps.wallet'
    label = 'wallet'
