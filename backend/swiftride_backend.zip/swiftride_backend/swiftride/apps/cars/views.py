from rest_framework import generics, status, permissions, filters
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from django_filters.rest_framework import DjangoFilterBackend
from swiftride.apps.companies.permissions import IsCompanyAdmin, IsCompanyStaff
from swiftride.apps.audit.utils import log_action
from .models import Car, CarImage, CarFeature, FavoriteCar
from .serializers import CarSerializer, CarMiniSerializer, CarImageSerializer, FavoriteCarSerializer
from .filters import CarFilter


class CarListView(generics.ListAPIView):
    serializer_class   = CarMiniSerializer
    permission_classes = [permissions.AllowAny]
    queryset           = Car.objects.filter(status='available').select_related('company').prefetch_related('images')
    filter_backends    = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class    = CarFilter
    search_fields      = ['name', 'brand', 'model', 'company__name']
    ordering_fields    = ['price_per_day', 'avg_rating', 'created_at']


class CarDetailView(generics.RetrieveAPIView):
    serializer_class   = CarSerializer
    permission_classes = [permissions.AllowAny]
    queryset           = Car.objects.all().select_related('company').prefetch_related('images', 'features')


class CompanyCarListView(generics.ListCreateAPIView):
    """Company staff sees & manages their own fleet."""
    permission_classes = [IsCompanyStaff]

    def get_serializer_class(self):
        return CarSerializer if self.request.method == 'POST' else CarMiniSerializer

    def get_queryset(self):
        return Car.objects.filter(company=self.request.user.company)

    def perform_create(self, serializer):
        car = serializer.save(company=self.request.user.company)
        # Update company car count
        company = self.request.user.company
        company.total_cars     = company.cars.count()
        company.available_cars = company.cars.filter(status='available').count()
        company.save(update_fields=['total_cars', 'available_cars'])
        log_action(self.request.user, 'create', 'Car', str(car.id), f'Car {car.name} added to fleet')


class CompanyCarDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class   = CarSerializer
    permission_classes = [IsCompanyStaff]

    def get_queryset(self):
        return Car.objects.filter(company=self.request.user.company)

    def perform_destroy(self, instance):
        log_action(self.request.user, 'delete', 'Car', str(instance.id), f'{instance.name} removed')
        instance.delete()


class CarImageUploadView(generics.CreateAPIView):
    serializer_class   = CarImageSerializer
    permission_classes = [IsCompanyStaff]

    def perform_create(self, serializer):
        car = Car.objects.get(pk=self.kwargs['car_pk'], company=self.request.user.company)
        serializer.save(car=car)


class FavoriteListView(generics.ListAPIView):
    serializer_class = FavoriteCarSerializer

    def get_queryset(self):
        return FavoriteCar.objects.filter(user=self.request.user).select_related('car')


class FavoriteToggleView(generics.GenericAPIView):
    def post(self, request, car_pk):
        car = Car.objects.get(pk=car_pk)
        fav, created = FavoriteCar.objects.get_or_create(user=request.user, car=car)
        if not created:
            fav.delete()
            return Response({'favorited': False})
        return Response({'favorited': True}, status=status.HTTP_201_CREATED)
